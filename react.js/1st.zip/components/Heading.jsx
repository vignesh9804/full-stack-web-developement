var React = require("react");
function Heading() {
  return (
    <div>
      <header>
        <h1>VTown</h1>
      </header>
    </div>
  );
}
export default Heading;
