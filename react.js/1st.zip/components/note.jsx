var React = require("react");
function Note() {
  return (
    <div className="note">
      <h1>list</h1>
      <p>
        For the next several decades, IBM would become an industry leader in
        several emerging technologies, including electric typewriters,
        electromechanical calculators, and personal computers.
      </p>
    </div>
  );
}
export default Note;
